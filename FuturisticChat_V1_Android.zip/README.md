# Futuristic Chat V1

Android Studio project for the first installable prototype.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on Android.

This V1 is a UI prototype. Real authentication, backend messaging, push notifications, encrypted storage and production-grade E2EE will be added in later phases.
