package com.futuristicchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B14)
private val Card = Color(0xFF101827)
private val Accent = Color(0xFF00D9FF)
private val TextPrimary = Color(0xFFEAF7FF)
private val TextSecondary = Color(0xFF8FA6B8)

data class Chat(val name: String, val message: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FuturisticChatApp() }
    }
}

@Composable
fun FuturisticChatApp() {
    var selected by remember { mutableIntStateOf(0) }
    val chats = listOf(
        Chat("Aarav", "Hey! Welcome to Futuristic Chat.", "12:41"),
        Chat("Priya", "Your private space is ready.", "11:20"),
        Chat("Futuristic AI", "How can I help you today?", "10:05")
    )

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column {
                when (selected) {
                    0 -> HomeScreen(chats)
                    1 -> ContactsScreen()
                    2 -> ProfileScreen()
                    3 -> SettingsScreen()
                }
                NavigationBar(
                    containerColor = Color(0xFF0A101C),
                    contentColor = TextPrimary
                ) {
                    val labels = listOf("Chats", "Contacts", "Profile", "Settings")
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Text(if (index == 0) "●" else "○", color = if (selected == index) Accent else TextSecondary) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(chats: List<Chat>) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("FUTURISTIC", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Chat", color = TextPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Search chats", color = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Color(0xFF26364A),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                ),
                shape = RoundedCornerShape(18.dp)
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(chats) { chat ->
                ChatRow(chat)
            }
        }
    }
}

@Composable
fun ChatRow(chat: Chat) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Card, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(52.dp).background(Accent.copy(alpha = .15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(chat.name.take(1), color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(chat.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(chat.message, color = TextSecondary, maxLines = 1, fontSize = 13.sp)
        }
        Text(chat.time, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
fun ContactsScreen() {
    CenterScreen("CONTACTS", "Your contacts will appear here.")
}

@Composable
fun ProfileScreen() {
    CenterScreen("PROFILE", "Identity, username and account controls.")
}

@Composable
fun SettingsScreen() {
    CenterScreen("PRIVACY & SETTINGS", "Security, privacy, notifications and app controls.")
}

@Composable
fun CenterScreen(title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(subtitle, color = TextPrimary, fontSize = 20.sp)
    }
}
